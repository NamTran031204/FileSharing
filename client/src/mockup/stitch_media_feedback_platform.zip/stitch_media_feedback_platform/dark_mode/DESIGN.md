# Design System Specification: The Deep Media Canvas

## 1. Overview & Creative North Star
**Creative North Star: "The Cinematic Obsidian"**

This design system is engineered to disappear, allowing the creative professional's media content to take center stage while providing a high-precision toolkit at their fingertips. Unlike generic productivity tools that rely on rigid borders and flat grey boxes, this system treats the UI as a series of deep, illuminated layers. 

We break the "template" look through **Tonal Depth** and **Intentional Asymmetry**. By utilizing the deep indigo and purple tones provided, we create an environment that feels like a darkened editing suite. Information density is managed through sophisticated layering rather than lines, ensuring the interface feels expansive yet organized.

---

## 2. Colors: Tonal Architecture
The palette is built on a foundation of deep nocturnal purples, moving away from "true black" to create a more sophisticated, premium atmosphere.

### The "No-Line" Rule
**Strict Mandate:** 1px solid borders are prohibited for sectioning. 
Structure must be defined through background color shifts. For instance, a side panel in `surface-container-low` (#0d1154) sits against a main canvas of `surface` (#03054d). The eye perceives the boundary through the change in luminosity, not a harsh stroke.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of materials.
- **Base (Canvas):** `surface` (#03054d) – The deepest layer for the primary workspace.
- **Lower Priority (Backgrounds):** `surface-container-low` (#0d1154) – Used for global sidebars.
- **High Priority (Panels):):** `surface-container-high` (#1d2262) – Used for inspector panels and active toolbars.
- **Elevated (Cards/Modals):** `surface-container-highest` (#292e6e) – The topmost layer for interactive elements.

### The "Glass & Gradient" Rule
For floating elements like annotation toolbars or version dropdowns, use Glassmorphism. Use the `surface-variant` (#292e6e) at 60% opacity with a `20px` backdrop blur. This ensures the media content is visible beneath the UI, creating an integrated, "pro-app" feel.

---

## 3. Typography: Editorial Precision
We utilize **Inter** for its neutral, technical clarity. The hierarchy is designed to feel like an editorial layout—wide tracking for labels and tight, bold headings for impact.

- **Display Scale:** Use `display-md` (2.75rem) for project titles. The letter-spacing should be set to -0.02em to create a bespoke, custom-built look.
- **Headline Scale:** `headline-sm` (1.5rem) should be used for folder names and media categories.
- **The Functional Label:** `label-md` (0.75rem) in uppercase with 5% letter-spacing is the signature style for technical metadata (e.g., Timecode, Resolution, FPS). 
- **Body:** `body-md` (0.875rem) using `on-surface-variant` (#c8c5d2) provides high readability without the harshness of pure white.

---

## 4. Elevation & Depth: Tonal Layering
Depth is communicative, not just decorative.

### Ambient Shadows
Forget "Drop Shadows." We use **Ambient Gloom**. When a floating card (like a file grid card) requires a lift, apply a shadow with a 40px blur, 0px offset, at 8% opacity. The color should be `#000145` (our lowest surface color) to mimic natural light absorption rather than a grey smudge.

### The "Ghost Border" Fallback
In high-density areas (like the timeline timeline) where a boundary is critical for accessibility, use the **Ghost Border**: `outline-variant` (#474550) at 15% opacity. It should be barely perceptible, serving as a subtle hint of a container.

---

## 5. Components: High-Performance Media Tools

### Video Player & Timeline
*   **The Scrubber:** Use `primary` (#A6A0ED) for the playhead. The timeline track should use `surface-container-highest` (#292e6e) to stand out against the `surface` background.
*   **Annotation Toolbar:** A floating glass container (`surface-variant` at 60% alpha) with `xl` (0.75rem) roundedness. 

### Interactive Elements
*   **Buttons:** 
    *   *Primary:* Use a subtle gradient from `primary` (#A6A0ED) to `primary-container` (#D2CAFF). This adds "soul" and a tactile quality.
    *   *Secondary:* Ghost style. No background, `outline` (#928f9b) text.
*   **File Grid Cards:** No borders. Use `surface-container-low` for the card base. On hover, transition the background to `surface-container-highest` and apply the Ambient Shadow.
*   **Version Dropdowns:** Should utilize `surface-bright` (#2d3272) to signify they are active, interactive surfaces that exist "above" the media.

### Inputs & Fields
*   **Text Inputs:** Use `surface-container-lowest` (#000145) for the field background to create a "recessed" look. Use `primary` (#A6A0ED) only for the active focus state cursor and a subtle bottom glow.

---

## 6. Do's and Don'ts

### Do:
*   **DO** use whitespace as a separator. A 32px gap is more premium than a 1px line.
*   **DO** use the `primary-fixed` (#e4dfff) color for hover states on icons to create a "lit" effect.
*   **DO** ensure the most critical action (e.g., "Share" or "Approve") uses the `primary` purple to draw the eye instantly.

### Don't:
*   **DON'T** use pure white (#FFFFFF) for body text; it causes eye strain in dark environments. Use `on-surface-variant` (#c8c5d2).
*   **DON'T** use the `error` color (#ffb4ab) for anything other than critical destructive actions. For creative feedback, stay within the purple spectrum.
*   **DON'T** mix roundedness. Use `md` (0.375rem) for small components like buttons/inputs, and `xl` (0.75rem) for large containers like cards and panels. Consistency is professional.