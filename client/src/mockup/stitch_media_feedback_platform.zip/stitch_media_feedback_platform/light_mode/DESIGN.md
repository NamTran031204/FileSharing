# Design System Specification: The Ethereal Professional

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Curated Gallery."**

Moving away from the high-contrast density of traditional dark modes, we are pivoting toward a high-end, editorial light interface. This system treats media assets not as data points, but as artifacts in a digital gallery. We achieve a "sophisticated feel" by breaking the rigid, boxed-in layouts of standard SaaS platforms. Instead of grids defined by lines, we use **intentional asymmetry, expansive white space, and tonal depth.** The result is an interface that feels breathable, prestigious, calm, and spacious—allowing the media being reviewed to take center stage.

---

## 2. Colors & Surface Architecture
Our palette uses a sophisticated range of indigos and lavenders to create a "toned" interface that is softer and more premium than pure grayscale.

### The "No-Line" Rule
**Explicit Instruction:** 1px solid borders are prohibited for sectioning. Structural boundaries must be defined exclusively through background color shifts. A `surface-container-low` section sitting on a `surface` background provides all the definition a professional eye needs.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine paper or frosted glass.
- **Base Layer:** `surface` (#fbf8ff) - The canvas. This is now represented by `neutral_color_hex`.
- **Secondary Sectioning:** `surface-container-low` (#f4f2ff) - For sidebars or subtle content grouping.
- **Elevated Content:** `surface-container-lowest` (#ffffff) - Reserved for primary cards or focal points to make them "pop" against the toned background.
- **Deep Nesting:** `surface-container-high` (#e7e6ff) - Used for inset elements like search bars or code blocks within a card.

### The "Glass & Gradient" Rule
To escape the "flat" look, use Glassmorphism for floating elements (modals, dropdowns, floating headers).
- **Token:** `surface` at 80% opacity with a `20px` backdrop-blur.
- **Signature Gradients:** For primary CTAs and hero states, use a linear gradient from `primary` (#3b3a7e) to `primary_container` (#535297) at a 135-degree angle. This adds a subtle "soul" and dimension that flat hex codes cannot replicate.

---

## 3. Typography
We use **Inter** not as a system font, but as an editorial tool. The hierarchy is designed to create a clear "rhythm" on the page.

- **Display (LG/MD/SM):** Set with `-0.02em` letter spacing. These are your "Editorial Statements." Use them sparingly to introduce major sections.
- **Headline (LG/MD/SM):** High-contrast `on_surface` (#0d1154). These should feel authoritative.
- **Title (LG/MD/SM):** Used for card headings and navigational elements.
- **Body (LG/MD/SM):** Optimized for readability. Use `on_surface_variant` (#474650) for secondary body text to reduce visual noise.
- **Labels:** Always uppercase with `+0.05em` letter spacing when used for badges or small metadata to ensure a premium, "labeled" feel.

---

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering**, not structural scaffolding.

### The Layering Principle
Instead of a shadow, place a `surface_container_lowest` (#ffffff) card on top of a `surface_container_low` (#f4f2ff) background. This creates a "soft lift" that feels architectural rather than digital.

### Ambient Shadows
When an element must float (e.g., a dragged media asset), use a "Toned Shadow":
- **Blur:** 32px to 48px.
- **Opacity:** 4% - 6%.
- **Color:** Use `primary` (#3b3a7e) instead of black. This ensures the shadow feels like a natural part of the environment.

### The "Ghost Border" Fallback
If accessibility requirements demand a container edge, use a **Ghost Border**:
- `outline_variant` (#c8c5d2) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`). White text. Subtle roundedness (roundedness: 1) corner radius.
- **Secondary:** Surface-tinted. No border. Background: `secondary_container` (#b5b1fe) at 30% opacity. Text: `primary` (#3b3a7e).
- **Tertiary:** Pure text with `primary` color. Interaction state is a subtle `surface_variant` ghost background.

### Cards & Lists
**Forbid the use of divider lines.**
- Use `1.5rem` to `2rem` of vertical white space to separate list items.
- For media cards, use `surface_container_lowest` with an ultra-soft ambient shadow.

### Input Fields
- **Background:** `surface_container_low` (#f4f2ff).
- **Border:** None for the default state.
- **Active State:** A 2px "Ghost Border" of `primary` at 40% opacity and a subtle `surface_bright` inner glow.

### Additional Signature Components
- **Media Tiers:** Use `tertiary` (#A6A0ED) for "High Priority" or "Approved" badges.
- **The Glass Header:** A fixed top navigation using the Glassmorphism rule to allow media content to scroll beautifully underneath.

---

## 6. Do's and Don'ts

### Do
- **Do** use asymmetrical padding (e.g., more padding on the left than the right in a hero section) to create an editorial feel.
- **Do** use `on_surface_variant` for "de-emphasized" information rather than making it smaller.
- **Do** lean into the "Toned" nature of the background—pure white should be a rare privilege for the highest-level cards.

### Don't
- **Don't** use 100% black (#000000) or high-contrast gray borders.
- **Don't** use standard "Drop Shadows" from default UI kits; they muddy the sophisticated indigo palette.
- **Don't** crowd the interface. If a screen feels full, increase the `spacing` rather than adding more dividers.